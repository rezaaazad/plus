<div class="white_card">
    <div class="nocontent_section">
        <div class="nocontent_section__image">
            <img src="<?php echo WOODPLUS_ASSET ?>img/notification-none.png">
        </div>
        <h5 class="nocontent_section__title">
            هیچ اعلانی ندارید.
        </h5>
    </div>
</div>